public class ArmstarongNum {
    public static void main(String[] args) {
        // 121= 1*1*1 + 2*2*2 + 1*1*1
        // 153 = 1*1*1 + 5*5*5 + 3*3*3

        int num = 150;
        int rev = 0, rem;
        int m = num;
        while (num>0){
            rem=num%10;
            rev=rem*rem*rem+rev;
            num=num/10;
        }
        if(m==rev){
            System.out.println("True");
        }
        else {
            System.out.println("false");
        }

    }
}
